NOTE:
	The images were rendered with crt_2ntscFS().
	The images were scaled/stretched to fit the active video portion of the NTSC signal.

Folders:

original/
	- contains images from https://junkerhq.net/xrgb/index.php?title=240p_test_suite
	- contains SMPTE NTSC color bar image
	- contains Philips PM5544 test pattern

chromapat0_i/
	- contains screen captures of interlaced frames with vertically aligned chroma (non-standard 228 chroma clocks per line)

chromapat0_p/
	- contains screen captures of progressive frames with vertically aligned chroma (non-standard 228 chroma clocks per line)

chromapat1_i/
	- contains screen captures of interlaced frames with checkered chroma (standard 227.5 chroma clocks per line)

chromapat1_p/
	- contains screen captures of progressive frames with checkered chroma (standard 227.5 chroma clocks per line)

- EMMIR (LMP88959)